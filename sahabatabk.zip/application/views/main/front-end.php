<?php

$this->load->view("partials/head");
$this->load->view("partials/navbar");
$this->load->view($page,$content);
$this->load->view("partials/footer");
